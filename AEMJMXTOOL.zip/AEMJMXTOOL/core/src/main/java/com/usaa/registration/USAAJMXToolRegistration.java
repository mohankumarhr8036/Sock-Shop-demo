// CustomJMXToolRegistration.java
package com.usaa.registration;

import com.usaa.USAAJMXMbeanTool;
import com.usaa.USAAJMXTool;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.metatype.annotations.Designate;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import java.lang.management.ManagementFactory;
import java.util.Dictionary;
import java.util.Hashtable;

@Component(service = USAAJMXToolRegistration.class)
@Designate(ocd = USAAJMXToolConfiguration.class)
public class USAAJMXToolRegistration {

    private USAAJMXMbeanTool USAAJMXTool;
    private ServiceRegistration<USAAJMXMbeanTool> registration;

    @Activate
    protected void activate(USAAJMXToolConfiguration configuration, BundleContext bundleContext) {
        USAAJMXTool = new USAAJMXMbeanTool();

        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
        try {
            ObjectName name = new ObjectName("com.usaa:type=USAAJMXTool");
            mbs.registerMBean(USAAJMXTool, name);

            Dictionary<String, Object> properties = new Hashtable<>();
            properties.put("jmx.objectname", "com.usaa:type=USAAJMXTool");
            registration = bundleContext.registerService(USAAJMXMbeanTool.class, USAAJMXTool, properties);
        } catch (Exception e) {
            // Handle exception (logging or rethrow)
            e.printStackTrace();
        }
    }

    @Deactivate
    protected void deactivate() {
        if (registration != null) {
            registration.unregister();
        }
    }
}
