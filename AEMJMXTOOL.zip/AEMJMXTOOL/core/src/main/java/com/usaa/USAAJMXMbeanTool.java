// CustomJMXToolMBean.java
package com.usaa;


public interface USAAJMXMbeanTool {
    double getCpuUsage();
}