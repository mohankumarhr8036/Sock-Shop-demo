// CustomJMXToolConfiguration.java
package com.usaa.registration;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Custom JMX Tool Configuration", description = "Configuration for Custom JMX Tool")
public @interface USAAJMXToolConfiguration {

    @AttributeDefinition(name = "Enabled", description = "Enable the custom JMX tool")
    boolean enabled() default false;
}