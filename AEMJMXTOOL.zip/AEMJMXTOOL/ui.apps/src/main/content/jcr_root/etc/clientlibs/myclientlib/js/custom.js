// custom.js
$(function() {
    $.ajax({
        url: '/system/console/jmx/com.usaa:type=USAAJMXTool/getCpuUsage',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            if (data.value) {
                $('p').text('CPU Usage: ' + data.value + '%');
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
});